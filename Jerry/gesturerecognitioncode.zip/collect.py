import sys
import serial
import array
import time
import math
import numpy as np

# enum states
class states:
    initial,ready,steady,go,finish = range(5)

# struct used for feature and window
class fstruct:
    def __init__(self):
        self.x = []
        self.y = []
        self.z = []

# class lparam:
#     # learning parameter
#     theta = np.ones(76)
#     k = 2       # slope of cost function
#     decay_rate = 0.97
#     lrate = 1
#     scale_down = 300


def startAccessPoint():
    return array.array('B', [0xFF, 0x07, 0x03]).tostring()
 
def accDataRequest():
    return array.array('B', [0xFF, 0x08, 0x07, 0x00, 0x00, 0x00, 0x00]).tostring()

# global variables
#Open port
ser = serial.Serial(2,115200,timeout=1)
 
#Start access point
ser.write(startAccessPoint())



# Read accelerometer data
def readAcc(ser):
    ser.write(accDataRequest())
    accel = ser.read(7)
    
    xoffset = 8
    yoffset = -1
    zoffset = -20
 
    if len(accel) != 7 or (ord(accel[0]) == 0 and ord(accel[1]) == 0 and ord(accel[2]) == 0):
        return (257,257,257)
    
    if ord(accel[2])>127:
        z = ord(accel[2])-256
    else:
        z = ord(accel[2])
    
    if ord(accel[1])>127:
        y = ord(accel[1])-256
    else:
        y = ord(accel[1])
        
    if ord(accel[0])>127:
        x = ord(accel[0])-256
    else:
        x = ord(accel[0])
       
    # calibrate
    x = x-xoffset
    y = y-yoffset
    z = z-zoffset
       
    return (x,y,z)

def write_output(outfile,window):
    # write label
    while True:
        ges = raw_input('What is your gesture: ')
        if ges == 'up':
            outfile.write(ges+'\n')
            break
        elif ges == 'down':
            outfile.write(ges+'\n')
            break
        elif ges == 'right':
            outfile.write(ges+'\n')
            break
        elif ges == 'left':
            outfile.write(ges+'\n')
            break
        elif ges == 'front':
            outfile.write(ges+'\n')
            break
        elif ges == 'back':
            outfile.write(ges+'\n')
            break
        elif ges == 'none':
            outfile.write(ges+'\n')
            break
        else:
            print('invalid input -- please select from up/down/right/left/front/back')
    
    # write acceleration data
    outfile.write('x: '+str(window.x)+'\n')
    outfile.write('y: '+str(window.y)+'\n')
    outfile.write('z: '+str(window.z)+'\n')
    
    return

# learning functions
def analyze(window):
    
    gesture = 'Up'
#     f = np.float_(np.array([1] + window.x + window.y + window.z))
#     gesture = predict(f)
#     print(gesture)
#     i = raw_input('What is your gesture: ')
#     if i == 'w':
#         y = 1
#     else:
#         y = 0
#     
#     j = cost_func(y,f)
#     if j > 0:
#         dj = cost_func(y,f)
#         dtheta = -dj
#         #dtheta = -j/dj
#         lparam.theta = lparam.theta + lparam.lrate*dtheta
#     
#         lparam.lrate = lparam.lrate*lparam.decay_rate
#     
#     print('error: '+str(j))
#     print(lparam.theta)
    return gesture


# def predict(f):
#     h = np.dot(lparam.theta,f)/lparam.scale_down
#     if h > 0:
#         gesture = 'Up'
#     else:
#         gesture = "Not Up"
#     
#     
#     return gesture
# 
# def cost_func(y,f):
#     h = np.dot(lparam.theta,f)/lparam.scale_down
#     if y == 0:
#         j = (1-y)*max(lparam.k*(1+h),0)
#     else:
#         j = y*max(lparam.k*(1-h),0)
# 
#     return j
# 
# def d_cost_func(y,f):
#     if y == 0:
#         dj = lparam.k*f
#     else:
#         dj = -lparam.k*f
# 
#     return dj/lparam.scale_down


# initialize output file
try:
    outfile = open('gesture_data.txt','w')
except:
    sys.exit('output file can\'t be opened')
    


# start processing
g = 50
wlen = 25
x = 0
y = 0
z = 0
state = states.initial
tstart = time.time()
timer = time.time()
window = fstruct()
print("start")
while (time.time()-tstart)<600:
    # state operations
    print('state is '+str(state))
    if state == states.ready:
        while True:
            (x,y,z) = readAcc(ser)
#             print('.')
            if x<256 and y<256 and z<256:
                break           
    elif state == states.steady:
        while True:
            (x,y,z) = readAcc(ser)
            if x<256 and y<256 and z<256:
                break
    elif state == states.go:
        while True:
            (x,y,z) = readAcc(ser)
            if x<256 and y<256 and z<256:
                break        
        window.x.append(x)
        window.y.append(y)
        window.z.append(z)
    elif state == states.finish:
        pass
    else:
        pass
        
        
    
    # state transitions
    if state == states.initial:
        next_state = states.ready
        timer = time.time()
    elif state == states.ready:
        print(str(x)+' '+str(y)+' '+str(z))
        print(math.sqrt(x**2+y**2+z**2))
        if abs(math.sqrt(x**2+y**2+z**2)-g) > 0.1*g:
            next_state = states.ready
            timer = time.time()
        else:
            if time.time()-timer > 0.5:
                next_state = states.steady
                timer = time.time()
            else:
                next_state = states.ready
    elif state == states.steady:
        #print(math.sqrt(x**2+y**2+z**2))
        if abs(math.sqrt(x**2+y**2+z**2)-g) > 0.1*g:
            next_state = states.go
            timer = time.time()
        else:
            next_state = states.steady
            timer = time.time()
    elif state == states.go:
        if len(window.x) >= wlen:
            next_state = states.finish
            timer = time.time()
        else:
            next_state = states.go
    elif state == states.finish:
        # gesture recognition and actions
        gesture = analyze(window)
        print(gesture)
        print(window.x)
        print(window.y)
        print(window.z)
        
        # record data
        write_output(outfile,window)
        
        # clear window and transit
        window.x = []
        window.y = []
        window.z = []
        next_state = states.ready
        timer = time.time()

                   
    state = next_state

outfile.close()
print('finish') 
