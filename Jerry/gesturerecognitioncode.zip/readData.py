import sys

try:
#     infile = open('data_set_1.txt')
    infile = open('gesture_data.txt')
except:
    sys.exit('can\'t open gesture_data.txt')
    
    
c_up = 0
c_down = 0
c_left = 0
c_right = 0
c_front = 0
c_back = 0
c_none = 0

for line in infile:
    if line == 'up\n':
        c_up += 1
    elif line == 'down\n':
        c_down += 1
    elif line == 'right\n':
        c_right += 1
    elif line == 'left\n':
        c_left += 1
    elif line == 'front\n':
        c_front += 1
    elif line == 'back\n':
        c_back += 1
    elif line == 'none\n':
        c_none += 1

c_total = c_up+c_down+c_right+c_left+c_front+c_back+c_none
        
print('up: '+str(c_up))
print('down: '+str(c_down))
print('right: '+str(c_right))
print('left: '+str(c_left))
print('front: '+str(c_front))
print('back: '+str(c_back))
print('none: '+str(c_none))
print('total: '+str(c_total))